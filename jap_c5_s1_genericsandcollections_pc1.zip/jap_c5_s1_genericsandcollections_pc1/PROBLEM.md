## Practice Statement :A Mobile Phone List​

***Imagine that you wish to purchase a mobile phone with specifications that include the brand name, cost, screen size, battery life, storage space and camera pixels. You have a list of the latest models available. Create a program that performs the following activities given in the list:​**

    1. Find phones of a particular brand.
    2. Find the phones whose cost is $500 and above.
    3. Enlist the phones which have camera specification as 12 MP and more

###Note : Read the mobile.csv, that contains the specifications.
