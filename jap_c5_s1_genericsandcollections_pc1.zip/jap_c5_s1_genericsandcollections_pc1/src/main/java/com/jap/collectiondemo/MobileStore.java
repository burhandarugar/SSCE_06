package com.jap.collectiondemo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class MobileStore
{
	private static List<Mobile> mobiles;
    public MobileStore()
    {
    	mobiles = new ArrayList<Mobile>();
    }
    public static List<Mobile> readMobileData(String fileName) 
    {
      try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String brandName = parts[0];
                String modelName = parts[1];
                double cost = Double.parseDouble(parts[2]);
                String size = parts[3];
                String battery = parts[4];
                String storageSpace = parts[5];
                int cameraPixelsMP = Integer.parseInt(parts[6]);
                Mobile mobile = new Mobile(brandName, modelName, cost, size, battery, storageSpace, cameraPixelsMP);
                mobiles.add(mobile);
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mobiles;
    }
    //Find phones of a particular brand.
    public List<Mobile> findPhoneByBrand(String brandName)
    {
    	List<Mobile> Brand = new ArrayList<Mobile>();
    	for(Mobile mobile :mobiles)
    	{
    		if(mobile.getBrandName().matches(brandName))
    		{
    			Brand.add(mobile);
    		}
    	}		
		return Brand;
    }

    //Find the phones whose cost is $500 and above.
    public List<Mobile> findPhoneCostMoreThan500$()
    {    
    	List<Mobile> Cost = new ArrayList<Mobile>();
	    for(Mobile mobile :mobiles)
	    {
		   if(mobile.getCost()>500)
		    {
			   Cost.add(mobile);
		    }
	    }		
	    return Cost;
    }

    //Enlist the phones which have camera specification as 12 MP and more
    public List<Mobile> findPhonePixelMoreThan12MP()
    {
    	List<Mobile> Pixel = new ArrayList<Mobile>();
	    for(Mobile mobile :mobiles)
	    {
		   if(mobile.getCameraPixels()>12)
		    {
			   Pixel.add(mobile);
		    }
	    }		
	    return Pixel;
    }
}

